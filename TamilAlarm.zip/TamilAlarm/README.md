# ABH voice clock

- ஒவ்வொரு மணிக்கும் தமிழில் நேரம் சொல்லும்: "ஒரு மணிக்கு நேரம், அதிகாலை ஒரு மணி."
- நேரம் சொன்னதும் அந்த மணிக்கான வசனம் சொல்லும் (24 மணிக்கும் தனித்தனி).
- அலாரம் அமைக்கலாம்; அடிக்கும்போது இப்போதுள்ள நேரத்தைத் தமிழில் சொல்லும்.

## APK எடுப்பது எப்படி (GitHub)

1. GitHub-ல் புதிய repository உருவாக்கவும்.
2. இந்த `TamilAlarm.zip` file-ஐ repo-வில் **Add file → Upload files** மூலம் ஏற்றவும் (unzip செய்யத் தேவையில்லை).
3. **Add file → Create new file** → பெயர்: `.github/workflows/build.yml` → `build.yml` உள்ளடக்கத்தை ஒட்டி Commit செய்யவும்.
4. **Actions** tab-ல் "Build APK" ஓடும் (3-5 நிமிடம்).
5. முடிந்ததும் repo-வின் **Releases** பகுதியில் `TamilAlarm.apk` கிடைக்கும். Phone-ல் download செய்து install செய்யவும்.

## வசனங்கள்

R.C. பைபிள் வாசகத்தை app-க்குள் **"வசனங்களை மாற்று"** பக்கத்தில் ஒவ்வொரு மணிக்கும் ஒட்டிச் சேமிக்கவும். வாசகம் காலியாக இருந்தால் வசன முகவரி மட்டும் சொல்லப்படும். (`app/src/main/assets/verses.json`-ல் இயல்பு முகவரிகள் உள்ளன.)

## குறிப்பு

Phone-ல் Google "Text-to-speech" engine-ல் Tamil voice data install ஆகியிருக்க வேண்டும்.
