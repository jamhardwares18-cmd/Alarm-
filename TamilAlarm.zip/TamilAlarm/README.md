# ABH voice clock

- ஒவ்வொரு மணிக்கும்: பாடல் → நேரம் → வசனம் (மூன்றும் தனித்தனியாக ON/OFF).
- பாடல்களும் வசனங்களும் ஞாயிறு முதல் சனி வரை நாள் வாரியாக.
- அலாரம்: நாட்கள், சொந்தப் பாடல், பாடல்/நேரம்/வசனம் தனித்தனி ON/OFF.

## APK எடுப்பது எப்படி (GitHub)

1. GitHub repo-வில் பழைய `TamilAlarm.zip`-ஐ delete செய்யவும்.
2. புதிய `TamilAlarm.zip`-ஐ Upload செய்து Commit செய்யவும் (unzip வேண்டாம்).
3. `.github/workflows/build.yml` இருக்க வேண்டும்.
4. Actions → Build APK முடிந்ததும் Releases-ல் `TamilAlarm.apk`.

இந்த version-லிருந்து, அடுத்த APK-க்களை uninstall செய்யாமல் மேலேயே install செய்யலாம்.
