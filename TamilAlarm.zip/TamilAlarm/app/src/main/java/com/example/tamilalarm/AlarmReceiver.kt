package com.example.tamilalarm

import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import java.util.Calendar

class AlarmReceiver : BroadcastReceiver() {
    override fun onReceive(context: Context, intent: Intent) {
        when (intent.action) {
            Scheduler.ACTION_HOURLY -> {
                Scheduler.scheduleHourly(context) // line up the next hour first
                val hourNow = Calendar.getInstance().get(Calendar.HOUR_OF_DAY)
                if (Prefs.hourly(context) && !Prefs.isQuietHour(context, hourNow)) {
                    SpeakService.start(context, SpeakService.MODE_HOURLY)
                }
            }
            Scheduler.ACTION_ALARM -> {
                val id = intent.getIntExtra(Scheduler.EXTRA_ID, -1)
                val alarm = Prefs.alarms(context).firstOrNull { it.id == id }
                if (alarm != null && alarm.enabled) {
                    if (alarm.days == 0) {
                        // one-time alarm: switch it off after it rings
                        Prefs.updateAlarm(context, alarm.copy(enabled = false))
                    } else {
                        Scheduler.scheduleAlarm(context, alarm) // next selected day
                    }
                    SpeakService.start(context, SpeakService.MODE_ALARM, id)
                }
            }
        }
    }
}
