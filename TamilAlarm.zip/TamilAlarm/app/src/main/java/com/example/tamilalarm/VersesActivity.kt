package com.example.tamilalarm

import android.app.Activity
import android.os.Bundle
import android.text.InputType
import android.view.View
import android.widget.AdapterView
import android.widget.ArrayAdapter
import android.widget.Button
import android.widget.EditText
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.Spinner
import android.widget.TextView
import android.widget.Toast
import java.util.Calendar

/** Lets the user paste the verse reference + text for each of the 24 hours, separately for each weekday. */
class VersesActivity : Activity() {

    private val refFields = ArrayList<EditText>()
    private val textFields = ArrayList<EditText>()
    private var day = -1 // -1 until the first selection is made

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        val pad = (16 * resources.displayMetrics.density).toInt()
        val today = Calendar.getInstance().get(Calendar.DAY_OF_WEEK) - 1

        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(pad, pad, pad, pad)
        }
        root.addView(TextView(this).apply {
            setText(R.string.verses_note)
            textSize = 14f
        })

        // The 24 boxes are built first so the spinner can fill them when it fires.
        val boxes = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
        for (h in 0..23) {
            boxes.addView(TextView(this).apply {
                text = "%02d:00  (%s)".format(h, TamilTime.period(h))
                textSize = 18f
                setPadding(0, pad, 0, 0)
            })
            val ref = EditText(this).apply {
                hint = "வசன முகவரி (எ.கா. யோவான் 3:16)"
                setSingleLine()
            }
            val text = EditText(this).apply {
                hint = "வசன வாசகம்"
                minLines = 2
                inputType = InputType.TYPE_CLASS_TEXT or InputType.TYPE_TEXT_FLAG_MULTI_LINE
            }
            refFields.add(ref)
            textFields.add(text)
            boxes.addView(ref)
            boxes.addView(text)
        }

        val spinner = Spinner(this)
        spinner.adapter = ArrayAdapter(
            this, android.R.layout.simple_spinner_dropdown_item, TamilTime.dayNames
        )
        spinner.onItemSelectedListener = object : AdapterView.OnItemSelectedListener {
            override fun onItemSelected(p: AdapterView<*>?, v: View?, pos: Int, id: Long) {
                if (day >= 0) saveCurrent() // keep what was typed for the previous day
                day = pos
                load()
            }

            override fun onNothingSelected(p: AdapterView<*>?) {}
        }
        root.addView(spinner)
        root.addView(Button(this).apply {
            setText(R.string.copy_all)
            setOnClickListener {
                saveCurrent()
                Verses.copyToAll(this@VersesActivity, day)
                Toast.makeText(this@VersesActivity, R.string.copied, Toast.LENGTH_SHORT).show()
            }
        })
        root.addView(boxes)
        root.addView(Button(this).apply {
            setText(R.string.save)
            setOnClickListener {
                saveCurrent()
                Toast.makeText(this@VersesActivity, R.string.saved, Toast.LENGTH_SHORT).show()
                finish()
            }
        })

        setContentView(ScrollView(this).apply { addView(root) })
        spinner.setSelection(today)
    }

    private fun load() {
        val list = Verses.all(this, day)
        for (h in 0..23) {
            refFields[h].setText(list[h].ref)
            textFields[h].setText(list[h].text)
        }
    }

    private fun saveCurrent() {
        if (day < 0) return
        val list = (0..23).map { i ->
            Verses.Verse(refFields[i].text.toString().trim(), textFields[i].text.toString().trim())
        }
        Verses.save(this, day, list)
    }

    override fun onPause() {
        saveCurrent() // never lose typed text if the user leaves the page
        super.onPause()
    }
}
