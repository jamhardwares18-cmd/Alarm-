package com.example.tamilalarm

import android.app.Activity
import android.app.TimePickerDialog
import android.content.Intent
import android.net.Uri
import android.os.Bundle
import android.view.Gravity
import android.widget.Button
import android.widget.CheckBox
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.Switch
import android.widget.TextView
import java.util.Calendar

/** Create or edit one alarm: time, weekdays, its own song, and separate song / time / verse switches. */
class AlarmEditActivity : Activity() {

    companion object {
        const val EXTRA_ID = "alarm_edit_id"
        private const val REQ_SONG = 1
    }

    private var editId = -1
    private var hour = 6
    private var minute = 0
    private var songUri = ""
    private var songName = ""
    private var enabled = true

    private lateinit var timeBtn: Button
    private lateinit var songText: TextView
    private val dayBoxes = ArrayList<CheckBox>()
    private lateinit var swSong: Switch
    private lateinit var swTime: Switch
    private lateinit var swVerse: Switch

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        val pad = (16 * resources.displayMetrics.density).toInt()

        editId = intent.getIntExtra(EXTRA_ID, -1)
        val existing = Prefs.alarms(this).firstOrNull { it.id == editId }
        val now = Calendar.getInstance()
        hour = existing?.hour ?: now.get(Calendar.HOUR_OF_DAY)
        minute = existing?.minute ?: now.get(Calendar.MINUTE)
        songUri = existing?.songUri ?: ""
        songName = existing?.songName ?: ""
        enabled = existing?.enabled ?: true
        val days = existing?.days ?: 127

        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(pad, pad, pad, pad)
        }
        root.addView(TextView(this).apply {
            setText(R.string.alarm_edit_title)
            textSize = 26f
            setTypeface(typeface, android.graphics.Typeface.BOLD)
        })

        timeBtn = Button(this).apply {
            textSize = 26f
            setOnClickListener { pickTime() }
        }
        root.addView(timeBtn)

        root.addView(TextView(this).apply {
            setText(R.string.alarm_days_note)
            textSize = 14f
            setPadding(0, pad, 0, 0)
        })
        val dayRow = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL }
        for (d in 0..6) {
            val box = CheckBox(this).apply {
                text = TamilTime.dayNames[d]
                textSize = 11f
                isChecked = ((days shr d) and 1) == 1
                gravity = Gravity.CENTER
            }
            dayBoxes.add(box)
            dayRow.addView(
                box,
                LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, 1f)
            )
        }
        root.addView(dayRow)
        root.addView(Button(this).apply {
            text = "எல்லா நாட்களும்"
            setOnClickListener { dayBoxes.forEach { it.isChecked = true } }
        })

        root.addView(TextView(this).apply {
            setText(R.string.alarm_song_label)
            textSize = 16f
            setPadding(0, pad, 0, 0)
        })
        songText = TextView(this).apply { textSize = 14f }
        root.addView(songText)
        val songRow = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL }
        songRow.addView(Button(this).apply {
            setText(R.string.pick)
            setOnClickListener { pickSong() }
        })
        songRow.addView(Button(this).apply {
            setText(R.string.delete)
            setOnClickListener {
                songUri = ""
                songName = ""
                refreshSong()
            }
        })
        root.addView(songRow)

        swSong = Switch(this).apply {
            setText(R.string.a_song)
            textSize = 16f
            isChecked = existing?.playSong ?: true
            minimumHeight = (48 * resources.displayMetrics.density).toInt()
        }
        swTime = Switch(this).apply {
            setText(R.string.a_time)
            textSize = 16f
            isChecked = existing?.sayTime ?: true
            minimumHeight = (48 * resources.displayMetrics.density).toInt()
        }
        swVerse = Switch(this).apply {
            setText(R.string.a_verse)
            textSize = 16f
            isChecked = existing?.sayVerse ?: true
            minimumHeight = (48 * resources.displayMetrics.density).toInt()
        }
        root.addView(swSong)
        root.addView(swTime)
        root.addView(swVerse)

        root.addView(Button(this).apply {
            setText(R.string.save)
            setOnClickListener { save() }
        })

        setContentView(ScrollView(this).apply { addView(root) })
        refreshTime()
        refreshSong()
    }

    private fun refreshTime() {
        val h12 = if (hour % 12 == 0) 12 else hour % 12
        timeBtn.text = "${TamilTime.period(hour)}  $h12:${"%02d".format(minute)}"
    }

    private fun refreshSong() {
        songText.text = if (songUri.isBlank()) getString(R.string.alarm_song_default) else songName
    }

    private fun pickTime() {
        TimePickerDialog(
            this,
            TimePickerDialog.OnTimeSetListener { _, h, m ->
                hour = h
                minute = m
                refreshTime()
            },
            hour,
            minute,
            false
        ).show()
    }

    private fun pickSong() {
        val i = Intent(Intent.ACTION_OPEN_DOCUMENT).apply {
            addCategory(Intent.CATEGORY_OPENABLE)
            type = "audio/*"
            addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION or Intent.FLAG_GRANT_PERSISTABLE_URI_PERMISSION)
        }
        startActivityForResult(i, REQ_SONG)
    }

    @Deprecated("Deprecated in Java")
    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        super.onActivityResult(requestCode, resultCode, data)
        if (requestCode == REQ_SONG && resultCode == RESULT_OK) {
            val uri: Uri = data?.data ?: return
            Songs.persist(this, uri)
            songUri = uri.toString()
            songName = Songs.displayName(this, uri)
            refreshSong()
        }
    }

    private fun save() {
        var mask = 0
        for (d in 0..6) if (dayBoxes[d].isChecked) mask = mask or (1 shl d)
        val item = AlarmItem(
            id = if (editId >= 0) editId else Prefs.nextId(this),
            hour = hour,
            minute = minute,
            enabled = true,
            days = mask,
            songUri = songUri,
            songName = songName,
            playSong = swSong.isChecked,
            sayTime = swTime.isChecked,
            sayVerse = swVerse.isChecked
        )
        val list = Prefs.alarms(this)
        if (list.any { it.id == item.id }) Prefs.updateAlarm(this, item)
        else Prefs.saveAlarms(this, list + item)
        Scheduler.scheduleAlarm(this, item)
        finish()
    }
}
