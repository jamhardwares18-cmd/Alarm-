package com.example.tamilalarm

import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.app.Service
import android.content.Context
import android.content.Intent
import android.content.pm.ServiceInfo
import android.media.AudioAttributes
import android.media.AudioManager
import android.media.MediaPlayer
import android.media.Ringtone
import android.media.RingtoneManager
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.os.Handler
import android.os.IBinder
import android.os.Looper
import android.os.PowerManager
import android.speech.tts.TextToSpeech
import android.speech.tts.UtteranceProgressListener
import androidx.core.app.NotificationCompat
import androidx.core.app.ServiceCompat
import androidx.core.content.ContextCompat
import java.util.Calendar
import java.util.Locale

/**
 * Plays the song, then says the time, then reads the verse. Each of the three can be switched
 * off separately (hourly: from the main screen; alarm: from that alarm's settings).
 * HOURLY mode: runs once and stops.
 * ALARM mode: repeats up to 5 times or until "நிறுத்து" is tapped.
 * Volumes are app-level (0..100 %) and never change the phone's own volume.
 */
class SpeakService : Service(), TextToSpeech.OnInitListener {

    companion object {
        const val EXTRA_MODE = "mode"
        const val EXTRA_ALARM = "alarm_item_id"
        const val MODE_HOURLY = "hourly"
        const val MODE_ALARM = "alarm"
        const val ACTION_STOP = "com.example.tamilalarm.STOP"
        private const val CHANNEL = "tamil_alarm"
        private const val NOTIF_ID = 42
        private const val MAX_ALARM_CYCLES = 5
        private const val MAX_SONG_MS = 5 * 60 * 1000L       // hourly song is cut off after 5 minutes
        private const val MAX_ALARM_SONG_MS = 2 * 60 * 1000L // alarm song is cut off after 2 minutes

        fun start(c: Context, mode: String, alarmId: Int = -1) {
            ContextCompat.startForegroundService(
                c,
                Intent(c, SpeakService::class.java)
                    .putExtra(EXTRA_MODE, mode)
                    .putExtra(EXTRA_ALARM, alarmId)
            )
        }
    }

    private var tts: TextToSpeech? = null
    private var ttsReady = false
    private var langOk = false
    private var mode = MODE_HOURLY
    private var alarm: AlarmItem? = null
    private var cycle = 0
    private var slotHour = 0
    private var slotDay = 0
    private val handler = Handler(Looper.getMainLooper())
    private var ringtone: Ringtone? = null
    private var wakeLock: PowerManager.WakeLock? = null
    private var player: MediaPlayer? = null
    private val songTimeout = Runnable { finishSong() }

    private val isAlarm get() = mode == MODE_ALARM

    override fun onBind(intent: Intent?): IBinder? = null

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        if (intent?.action == ACTION_STOP) {
            shutdown()
            return START_NOT_STICKY
        }
        mode = intent?.getStringExtra(EXTRA_MODE) ?: MODE_HOURLY
        val alarmId = intent?.getIntExtra(EXTRA_ALARM, -1) ?: -1
        alarm = if (isAlarm) Prefs.alarms(this).firstOrNull { it.id == alarmId } else null
        cycle = 0
        handler.removeCallbacksAndMessages(null)
        stopRingtone()
        releasePlayer()
        restoreVolume() // a new run starts from the phone's own volume again

        ServiceCompat.startForeground(
            this, NOTIF_ID, buildNotification(),
            ServiceInfo.FOREGROUND_SERVICE_TYPE_MEDIA_PLAYBACK
        )

        if (wakeLock == null) {
            val pm = getSystemService(Context.POWER_SERVICE) as PowerManager
            wakeLock = pm.newWakeLock(PowerManager.PARTIAL_WAKE_LOCK, "tamilalarm:speak")
                .apply { acquire(15 * 60 * 1000L) }
        }

        if (tts == null) {
            tts = TextToSpeech(this, this)
        } else if (ttsReady) {
            beginCycle()
        }
        return START_NOT_STICKY
    }

    override fun onInit(status: Int) {
        val t = tts ?: return
        if (status == TextToSpeech.SUCCESS) {
            val r = t.setLanguage(Locale("ta", "IN"))
            langOk = r >= TextToSpeech.LANG_AVAILABLE
            t.setOnUtteranceProgressListener(object : UtteranceProgressListener() {
                override fun onStart(utteranceId: String?) {}

                override fun onDone(utteranceId: String?) {
                    if (utteranceId == "last") handler.post { onSpeechFinished() }
                }

                @Deprecated("Deprecated in Java")
                override fun onError(utteranceId: String?) {
                    handler.post { onSpeechFinished() }
                }
            })
        } else {
            langOk = false
        }
        ttsReady = true
        beginCycle()
    }

    // ------------------------------------------------------------------ flow

    /** Step 1: the song (or ring), then step 2/3 in [speakNow]. */
    private fun beginCycle() {
        requestFocus()
        boostVolume()
        val cal = Calendar.getInstance()
        slotHour = cal.get(Calendar.HOUR_OF_DAY)
        slotDay = cal.get(Calendar.DAY_OF_WEEK) - 1

        if (isAlarm) {
            val a = alarm
            // If the user switched everything off, still ring so the alarm is not silent.
            val wantSong = a == null || a.playSong || (!a.sayTime && !a.sayVerse)
            if (!wantSong) {
                speakNow()
                return
            }
            val uri = a?.songUri?.takeIf { it.isNotBlank() }?.let { Uri.parse(it) }
            if (uri != null) {
                playSong(uri, AudioAttributes.USAGE_ALARM, Prefs.gain(this, Prefs.K_G_ALARM), MAX_ALARM_SONG_MS)
            } else {
                playRingtone(RingtoneManager.TYPE_ALARM)
                handler.postDelayed({
                    stopRingtone()
                    speakNow()
                }, 5000)
            }
        } else {
            val uri = if (Prefs.getFlag(this, Prefs.K_H_SONG)) Songs.uri(this, slotDay, slotHour) else null
            if (uri != null) {
                playSong(uri, AudioAttributes.USAGE_MEDIA, Prefs.gain(this, Prefs.K_G_MEDIA), MAX_SONG_MS)
            } else {
                speakNow()
            }
        }
    }

    private fun playSong(uri: Uri, usage: Int, gain: Float, maxMs: Long) {
        try {
            val mp = MediaPlayer()
            player = mp
            mp.setAudioAttributes(
                AudioAttributes.Builder()
                    .setUsage(usage)
                    .setContentType(AudioAttributes.CONTENT_TYPE_MUSIC)
                    .build()
            )
            mp.setDataSource(this, uri)
            mp.setVolume(gain, gain)
            mp.setOnCompletionListener { finishSong() }
            mp.setOnErrorListener { _, _, _ ->
                finishSong()
                true
            }
            mp.setOnPreparedListener { p ->
                p.start()
                handler.postDelayed(songTimeout, maxMs)
            }
            mp.prepareAsync()
        } catch (e: Exception) {
            releasePlayer()
            speakNow()
        }
    }

    private fun finishSong() {
        if (player == null) return
        handler.removeCallbacks(songTimeout)
        releasePlayer()
        speakNow()
    }

    private fun releasePlayer() {
        val p = player ?: return
        player = null
        try {
            p.stop()
        } catch (e: Exception) {
        }
        try {
            p.release()
        } catch (e: Exception) {
        }
    }

    /** Steps 2 and 3: time, then verse (each only if switched on). */
    private fun speakNow() {
        val a = alarm
        val sayTime = if (isAlarm) (a?.sayTime ?: true) else Prefs.getFlag(this, Prefs.K_H_TIME)
        val sayVerse = if (isAlarm) (a?.sayVerse ?: true) else Prefs.getFlag(this, Prefs.K_H_VERSE)

        val now = Calendar.getInstance()
        val hour: Int
        val day: Int
        if (isAlarm) {
            hour = now.get(Calendar.HOUR_OF_DAY)
            day = now.get(Calendar.DAY_OF_WEEK) - 1
        } else {
            hour = slotHour // the hour the announcement belongs to, even if the song ran long
            day = slotDay
        }

        val items = ArrayList<String>()
        if (sayTime) {
            items.add(
                if (isAlarm) TamilTime.alarm(hour, now.get(Calendar.MINUTE)) else TamilTime.hourly(hour)
            )
        }
        // In alarm mode the verse is read only in the first round.
        if (sayVerse && !(isAlarm && cycle > 0)) {
            Verses.speech(this, day, hour)?.let { if (it.isNotBlank()) items.add(it) }
        }

        if (items.isEmpty()) {
            onSpeechFinished()
            return
        }

        val t = tts
        if (t == null || !langOk) {
            // Tamil voice missing: just beep so the user still notices.
            if (!isAlarm) {
                playRingtone(RingtoneManager.TYPE_NOTIFICATION)
                handler.postDelayed({
                    stopRingtone()
                    onSpeechFinished()
                }, 3000)
            } else {
                onSpeechFinished()
            }
            return
        }

        t.setAudioAttributes(
            AudioAttributes.Builder()
                .setUsage(if (isAlarm) AudioAttributes.USAGE_ALARM else AudioAttributes.USAGE_MEDIA)
                .setContentType(AudioAttributes.CONTENT_TYPE_SPEECH)
                .build()
        )
        val gain = Prefs.gain(this, if (isAlarm) Prefs.K_G_ALARM else Prefs.K_G_MEDIA)
        items.forEachIndexed { i, text ->
            val params = Bundle().apply { putFloat(TextToSpeech.Engine.KEY_PARAM_VOLUME, gain) }
            val last = i == items.lastIndex
            if (i > 0) t.playSilentUtterance(700, TextToSpeech.QUEUE_ADD, "gap$i")
            t.speak(
                text,
                if (i == 0) TextToSpeech.QUEUE_FLUSH else TextToSpeech.QUEUE_ADD,
                params,
                if (last) "last" else "part$i"
            )
        }
    }

    private fun onSpeechFinished() {
        if (isAlarm) {
            cycle++
            if (cycle >= MAX_ALARM_CYCLES) {
                shutdown()
            } else {
                handler.postDelayed({ beginCycle() }, 4000)
            }
        } else {
            shutdown()
        }
    }

    // ------------------------------------------------------------------ helpers

    private fun playRingtone(type: Int) {
        stopRingtone()
        try {
            val uri = RingtoneManager.getDefaultUri(type)
            val r = RingtoneManager.getRingtone(this, uri) ?: return
            r.setAudioAttributes(
                AudioAttributes.Builder()
                    .setUsage(
                        if (type == RingtoneManager.TYPE_ALARM) AudioAttributes.USAGE_ALARM
                        else AudioAttributes.USAGE_NOTIFICATION
                    )
                    .setContentType(AudioAttributes.CONTENT_TYPE_SONIFICATION)
                    .build()
            )
            if (Build.VERSION.SDK_INT >= 28) {
                r.volume = Prefs.gain(
                    this,
                    if (type == RingtoneManager.TYPE_ALARM) Prefs.K_G_ALARM else Prefs.K_G_MEDIA
                )
            }
            r.play()
            ringtone = r
        } catch (e: Exception) {
            // ignore: speech still works
        }
    }

    private fun stopRingtone() {
        try {
            ringtone?.stop()
        } catch (e: Exception) {
        }
        ringtone = null
    }

    @Suppress("DEPRECATION")
    private fun requestFocus() {
        try {
            (getSystemService(Context.AUDIO_SERVICE) as AudioManager).requestAudioFocus(
                null, AudioManager.STREAM_MUSIC, AudioManager.AUDIOFOCUS_GAIN_TRANSIENT
            )
        } catch (e: Exception) {
        }
    }

    @Suppress("DEPRECATION")
    private fun abandonFocus() {
        try {
            (getSystemService(Context.AUDIO_SERVICE) as AudioManager).abandonAudioFocus(null)
        } catch (e: Exception) {
        }
    }

    private var boostedStream = -1

    /**
     * Makes the loudness independent of the phone's volume: the stream is set to maximum while
     * the app plays, and only the app's own slider (0-100 %) lowers it. The phone's volume is
     * put back afterwards.
     */
    private fun boostVolume() {
        if (boostedStream >= 0) return
        val stream = if (isAlarm) AudioManager.STREAM_ALARM else AudioManager.STREAM_MUSIC
        try {
            val am = getSystemService(Context.AUDIO_SERVICE) as AudioManager
            val pending = Prefs.savedVol(this, stream) // left over if the app was killed mid-play
            val original = if (pending >= 0) pending else am.getStreamVolume(stream)
            Prefs.setSavedVol(this, stream, original)
            am.setStreamVolume(stream, am.getStreamMaxVolume(stream), 0)
            boostedStream = stream
        } catch (e: Exception) {
            // e.g. Do Not Disturb blocks the change: the app slider still works on top of phone volume
        }
    }

    private fun restoreVolume() {
        val stream = boostedStream
        if (stream < 0) return
        boostedStream = -1
        try {
            val am = getSystemService(Context.AUDIO_SERVICE) as AudioManager
            val original = Prefs.savedVol(this, stream)
            if (original >= 0) am.setStreamVolume(stream, original, 0)
        } catch (e: Exception) {
        }
        Prefs.setSavedVol(this, stream, -1)
    }

    private fun cleanup() {
        handler.removeCallbacksAndMessages(null)
        stopRingtone()
        releasePlayer()
        tts?.stop()
        tts?.shutdown()
        tts = null
        ttsReady = false
        restoreVolume()
        abandonFocus()
        wakeLock?.let { if (it.isHeld) it.release() }
        wakeLock = null
    }

    private fun shutdown() {
        cleanup()
        stopForeground(STOP_FOREGROUND_REMOVE)
        stopSelf()
    }

    override fun onDestroy() {
        cleanup()
        super.onDestroy()
    }

    private fun buildNotification(): android.app.Notification {
        val nm = getSystemService(NotificationManager::class.java)
        if (Build.VERSION.SDK_INT >= 26 && nm.getNotificationChannel(CHANNEL) == null) {
            nm.createNotificationChannel(
                NotificationChannel(CHANNEL, "ABH voice clock", NotificationManager.IMPORTANCE_LOW)
            )
        }
        val flags = PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
        val stop = PendingIntent.getService(
            this, 1, Intent(this, SpeakService::class.java).setAction(ACTION_STOP), flags
        )
        val open = PendingIntent.getActivity(this, 2, Intent(this, MainActivity::class.java), flags)
        val title = if (isAlarm) "அலாரம்" else "நேர அறிவிப்பு"
        return NotificationCompat.Builder(this, CHANNEL)
            .setSmallIcon(android.R.drawable.ic_lock_idle_alarm)
            .setContentTitle(title)
            .setContentText("நிறுத்த 'நிறுத்து' தட்டவும்")
            .setContentIntent(open)
            .addAction(0, "நிறுத்து", stop)
            .setOngoing(true)
            .setPriority(NotificationCompat.PRIORITY_LOW)
            .build()
    }
}
