package com.example.tamilalarm

import android.content.Context
import android.media.AudioAttributes
import android.media.MediaPlayer
import android.net.Uri

/** Plays a chosen song inside the app so the user can listen before keeping it. One song at a time. */
object SongPreview {
    private var mp: MediaPlayer? = null

    /** Identifies what is playing now (null = nothing). */
    var key: String? = null
        private set

    /** Starts [uri] under [k]; if [k] is already playing, stops it instead. [onChange] updates the buttons. */
    fun toggle(c: Context, uri: Uri, k: String, onChange: () -> Unit) {
        if (key == k) {
            stop()
            onChange()
            return
        }
        stop()
        try {
            val p = MediaPlayer()
            mp = p
            key = k
            p.setAudioAttributes(
                AudioAttributes.Builder()
                    .setUsage(AudioAttributes.USAGE_MEDIA)
                    .setContentType(AudioAttributes.CONTENT_TYPE_MUSIC)
                    .build()
            )
            p.setDataSource(c.applicationContext, uri)
            val g = Prefs.gain(c, Prefs.K_G_MEDIA)
            p.setVolume(g, g)
            p.setOnCompletionListener {
                stop()
                onChange()
            }
            p.setOnErrorListener { _, _, _ ->
                stop()
                onChange()
                true
            }
            p.setOnPreparedListener { it.start() }
            p.prepareAsync()
        } catch (e: Exception) {
            stop()
        }
        onChange()
    }

    fun stop() {
        val p = mp
        mp = null
        key = null
        if (p != null) {
            try {
                p.stop()
            } catch (e: Exception) {
            }
            try {
                p.release()
            } catch (e: Exception) {
            }
        }
    }
}
