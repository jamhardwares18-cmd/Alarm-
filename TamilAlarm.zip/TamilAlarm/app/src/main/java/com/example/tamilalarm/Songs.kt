package com.example.tamilalarm

import android.content.Context
import android.content.Intent
import android.net.Uri
import android.provider.OpenableColumns
import org.json.JSONArray
import org.json.JSONObject

/** One audio file per hour of the day, separately for each weekday (0 = Sunday ... 6 = Saturday). */
object Songs {
    data class Song(val uri: String, val name: String)

    private fun empty() = List(24) { Song("", "") }

    fun all(c: Context, day: Int): List<Song> {
        val s = Prefs.songsJson(c, day) ?: return empty()
        return try {
            val arr = JSONArray(s)
            List(24) { i ->
                if (i < arr.length()) {
                    val o = arr.getJSONObject(i)
                    Song(o.optString("uri"), o.optString("name"))
                } else {
                    Song("", "")
                }
            }
        } catch (e: Exception) {
            empty()
        }
    }

    private fun save(c: Context, day: Int, list: List<Song>) {
        val arr = JSONArray()
        list.forEach { arr.put(JSONObject().put("uri", it.uri).put("name", it.name)) }
        Prefs.setSongsJson(c, day, arr.toString())
    }

    /** Keep access to a file the user picked, even after the app is closed or the phone restarts. */
    fun persist(c: Context, uri: Uri) {
        try {
            c.contentResolver.takePersistableUriPermission(uri, Intent.FLAG_GRANT_READ_URI_PERMISSION)
        } catch (e: Exception) {
        }
    }

    fun set(c: Context, day: Int, hour: Int, uri: Uri) {
        persist(c, uri)
        val list = all(c, day).toMutableList()
        list[hour] = Song(uri.toString(), displayName(c, uri))
        save(c, day, list)
    }

    fun clear(c: Context, day: Int, hour: Int) {
        val list = all(c, day).toMutableList()
        list[hour] = Song("", "")
        save(c, day, list)
    }

    fun uri(c: Context, day: Int, hour: Int): Uri? {
        val s = all(c, day).getOrNull(hour) ?: return null
        return if (s.uri.isBlank()) null else Uri.parse(s.uri)
    }

    fun copyToAll(c: Context, fromDay: Int) {
        val list = all(c, fromDay)
        for (d in 0..6) if (d != fromDay) save(c, d, list)
    }

    fun displayName(c: Context, uri: Uri): String {
        try {
            c.contentResolver.query(uri, arrayOf(OpenableColumns.DISPLAY_NAME), null, null, null)?.use {
                if (it.moveToFirst()) return it.getString(0) ?: ""
            }
        } catch (e: Exception) {
        }
        return uri.lastPathSegment ?: "song"
    }
}
