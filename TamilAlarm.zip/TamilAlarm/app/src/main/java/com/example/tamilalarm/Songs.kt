package com.example.tamilalarm

import android.content.Context
import android.content.Intent
import android.net.Uri
import android.provider.OpenableColumns
import org.json.JSONArray
import org.json.JSONObject

/** One audio file per hour of the day, chosen by the user from the phone. */
object Songs {
    data class Song(val uri: String, val name: String)

    private fun empty() = List(24) { Song("", "") }

    fun all(c: Context): List<Song> {
        val s = Prefs.songsJson(c) ?: return empty()
        return try {
            val arr = JSONArray(s)
            List(24) { i ->
                if (i < arr.length()) {
                    val o = arr.getJSONObject(i)
                    Song(o.optString("uri"), o.optString("name"))
                } else {
                    Song("", "")
                }
            }
        } catch (e: Exception) {
            empty()
        }
    }

    private fun save(c: Context, list: List<Song>) {
        val arr = JSONArray()
        list.forEach { arr.put(JSONObject().put("uri", it.uri).put("name", it.name)) }
        Prefs.setSongsJson(c, arr.toString())
    }

    fun set(c: Context, hour: Int, uri: Uri) {
        try {
            c.contentResolver.takePersistableUriPermission(uri, Intent.FLAG_GRANT_READ_URI_PERMISSION)
        } catch (e: Exception) {
        }
        val list = all(c).toMutableList()
        list[hour] = Song(uri.toString(), displayName(c, uri))
        save(c, list)
    }

    fun clear(c: Context, hour: Int) {
        val list = all(c).toMutableList()
        list[hour] = Song("", "")
        save(c, list)
    }

    fun uri(c: Context, hour: Int): Uri? {
        val s = all(c).getOrNull(hour) ?: return null
        return if (s.uri.isBlank()) null else Uri.parse(s.uri)
    }

    fun displayName(c: Context, uri: Uri): String {
        try {
            c.contentResolver.query(uri, arrayOf(OpenableColumns.DISPLAY_NAME), null, null, null)?.use {
                if (it.moveToFirst()) return it.getString(0) ?: ""
            }
        } catch (e: Exception) {
        }
        return uri.lastPathSegment ?: "song"
    }
}
