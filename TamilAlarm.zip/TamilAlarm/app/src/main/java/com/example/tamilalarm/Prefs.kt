package com.example.tamilalarm

import android.content.Context
import org.json.JSONArray
import org.json.JSONObject

/**
 * days: bit0 = Sunday ... bit6 = Saturday. 127 = every day, 0 = once only.
 */
data class AlarmItem(
    val id: Int,
    val hour: Int,
    val minute: Int,
    val enabled: Boolean,
    val days: Int = 127,
    val songUri: String = "",
    val songName: String = "",
    val playSong: Boolean = true,
    val sayTime: Boolean = true,
    val sayVerse: Boolean = true
)

object Prefs {
    const val K_H_SONG = "h_song"
    const val K_H_TIME = "h_time"
    const val K_H_VERSE = "h_verse"
    const val K_G_ALARM = "g_alarm"
    const val K_G_MEDIA = "g_media"

    private fun sp(c: Context) = c.getSharedPreferences("tamil_alarm", Context.MODE_PRIVATE)

    fun hourly(c: Context): Boolean = sp(c).getBoolean("hourly", false)

    fun setHourly(c: Context, on: Boolean) {
        sp(c).edit().putBoolean("hourly", on).apply()
    }

    // ---- simple on/off switches (default ON) ----
    fun getFlag(c: Context, key: String): Boolean = sp(c).getBoolean(key, true)

    fun setFlag(c: Context, key: String, on: Boolean) {
        sp(c).edit().putBoolean(key, on).apply()
    }

    // ---- app-level volume, 0..100 (does not touch the phone's own volume) ----
    fun getPct(c: Context, key: String): Int = sp(c).getInt(key, 100)

    fun setPct(c: Context, key: String, v: Int) {
        sp(c).edit().putInt(key, v).apply()
    }

    fun gain(c: Context, key: String): Float = getPct(c, key) / 100f

    // ---- Quiet hours: no hourly announcement between start (inclusive) and end (exclusive) ----
    fun quietOn(c: Context): Boolean = sp(c).getBoolean("quiet_on", false)

    fun setQuietOn(c: Context, on: Boolean) {
        sp(c).edit().putBoolean("quiet_on", on).apply()
    }

    /** Minutes after midnight. Default 11:00 PM. */
    fun quietStart(c: Context): Int = sp(c).getInt("quiet_start", 23 * 60)

    /** Minutes after midnight. Default 4:00 AM. */
    fun quietEnd(c: Context): Int = sp(c).getInt("quiet_end", 4 * 60)

    fun setQuiet(c: Context, start: Int, end: Int) {
        sp(c).edit().putInt("quiet_start", start).putInt("quiet_end", end).apply()
    }

    /** True if the top-of-the-hour announcement for [hour] must stay silent. */
    fun isQuietHour(c: Context, hour: Int): Boolean {
        if (!quietOn(c)) return false
        val s = quietStart(c)
        val e = quietEnd(c)
        if (s == e) return false
        val t = hour * 60
        return if (s < e) t in s until e else (t >= s || t < e)
    }

    // ---- alarms ----
    fun alarms(c: Context): List<AlarmItem> {
        return try {
            val arr = JSONArray(sp(c).getString("alarms", "[]"))
            List(arr.length()) { i ->
                val o = arr.getJSONObject(i)
                AlarmItem(
                    id = o.getInt("id"),
                    hour = o.getInt("h"),
                    minute = o.getInt("m"),
                    enabled = o.getBoolean("on"),
                    days = o.optInt("days", 127),
                    songUri = o.optString("song", ""),
                    songName = o.optString("sname", ""),
                    playSong = o.optBoolean("ps", true),
                    sayTime = o.optBoolean("st", true),
                    sayVerse = o.optBoolean("sv", true)
                )
            }
        } catch (e: Exception) {
            emptyList()
        }
    }

    fun saveAlarms(c: Context, list: List<AlarmItem>) {
        val arr = JSONArray()
        list.forEach {
            arr.put(
                JSONObject()
                    .put("id", it.id)
                    .put("h", it.hour)
                    .put("m", it.minute)
                    .put("on", it.enabled)
                    .put("days", it.days)
                    .put("song", it.songUri)
                    .put("sname", it.songName)
                    .put("ps", it.playSong)
                    .put("st", it.sayTime)
                    .put("sv", it.sayVerse)
            )
        }
        sp(c).edit().putString("alarms", arr.toString()).apply()
    }

    fun nextId(c: Context): Int = (alarms(c).maxOfOrNull { it.id } ?: 0) + 1

    fun updateAlarm(c: Context, item: AlarmItem) {
        saveAlarms(c, alarms(c).map { if (it.id == item.id) item else it })
    }

    fun removeAlarm(c: Context, id: Int) {
        saveAlarms(c, alarms(c).filter { it.id != id })
    }

    // ---- per-weekday songs and verses (day: 0 = Sunday ... 6 = Saturday) ----
    // Falls back to the old single list so earlier choices are not lost.
    fun songsJson(c: Context, day: Int): String? =
        sp(c).getString("songs_d$day", null) ?: sp(c).getString("songs", null)

    fun setSongsJson(c: Context, day: Int, json: String) {
        sp(c).edit().putString("songs_d$day", json).apply()
    }

    fun versesJson(c: Context, day: Int): String? =
        sp(c).getString("verses_d$day", null) ?: sp(c).getString("verses", null)

    fun setVersesJson(c: Context, day: Int, json: String) {
        sp(c).edit().putString("verses_d$day", json).apply()
    }
}
