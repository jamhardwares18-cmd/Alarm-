package com.example.tamilalarm

import android.content.Context
import org.json.JSONArray
import org.json.JSONObject

data class AlarmItem(val id: Int, val hour: Int, val minute: Int, val enabled: Boolean)

object Prefs {
    private fun sp(c: Context) = c.getSharedPreferences("tamil_alarm", Context.MODE_PRIVATE)

    fun hourly(c: Context): Boolean = sp(c).getBoolean("hourly", false)

    fun setHourly(c: Context, on: Boolean) {
        sp(c).edit().putBoolean("hourly", on).apply()
    }

    // ---- Quiet hours: no hourly announcement between start (inclusive) and end (exclusive) ----
    fun quietOn(c: Context): Boolean = sp(c).getBoolean("quiet_on", false)

    fun setQuietOn(c: Context, on: Boolean) {
        sp(c).edit().putBoolean("quiet_on", on).apply()
    }

    /** Minutes after midnight. Default 11:00 PM. */
    fun quietStart(c: Context): Int = sp(c).getInt("quiet_start", 23 * 60)

    /** Minutes after midnight. Default 4:00 AM. */
    fun quietEnd(c: Context): Int = sp(c).getInt("quiet_end", 4 * 60)

    fun setQuiet(c: Context, start: Int, end: Int) {
        sp(c).edit().putInt("quiet_start", start).putInt("quiet_end", end).apply()
    }

    /** True if the top-of-the-hour announcement for [hour] must stay silent. */
    fun isQuietHour(c: Context, hour: Int): Boolean {
        if (!quietOn(c)) return false
        val s = quietStart(c)
        val e = quietEnd(c)
        if (s == e) return false
        val t = hour * 60
        return if (s < e) t in s until e else (t >= s || t < e)
    }

    fun alarms(c: Context): List<AlarmItem> {
        return try {
            val arr = JSONArray(sp(c).getString("alarms", "[]"))
            List(arr.length()) { i ->
                val o = arr.getJSONObject(i)
                AlarmItem(o.getInt("id"), o.getInt("h"), o.getInt("m"), o.getBoolean("on"))
            }
        } catch (e: Exception) {
            emptyList()
        }
    }

    fun saveAlarms(c: Context, list: List<AlarmItem>) {
        val arr = JSONArray()
        list.forEach {
            arr.put(
                JSONObject()
                    .put("id", it.id)
                    .put("h", it.hour)
                    .put("m", it.minute)
                    .put("on", it.enabled)
            )
        }
        sp(c).edit().putString("alarms", arr.toString()).apply()
    }

    fun nextId(c: Context): Int = (alarms(c).maxOfOrNull { it.id } ?: 0) + 1

    fun updateAlarm(c: Context, item: AlarmItem) {
        saveAlarms(c, alarms(c).map { if (it.id == item.id) item else it })
    }

    fun removeAlarm(c: Context, id: Int) {
        saveAlarms(c, alarms(c).filter { it.id != id })
    }

    fun songsJson(c: Context): String? = sp(c).getString("songs", null)

    fun setSongsJson(c: Context, json: String) {
        sp(c).edit().putString("songs", json).apply()
    }

    fun versesJson(c: Context): String? = sp(c).getString("verses", null)

    fun setVersesJson(c: Context, json: String) {
        sp(c).edit().putString("verses", json).apply()
    }
}
