package com.example.tamilalarm

import android.app.Activity
import android.content.Intent
import android.net.Uri
import android.os.Bundle
import android.view.Gravity
import android.view.View
import android.widget.AdapterView
import android.widget.ArrayAdapter
import android.widget.Button
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.Spinner
import android.widget.TextView
import android.widget.Toast
import java.util.Calendar

/** Pick one song for each hour (0..23) of the selected weekday, or many at once. */
class SongsActivity : Activity() {

    companion object {
        private const val REQ_MULTI = 100
    }

    private val nameViews = ArrayList<TextView>()
    private var day = 0

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        val pad = (16 * resources.displayMetrics.density).toInt()
        day = Calendar.getInstance().get(Calendar.DAY_OF_WEEK) - 1

        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(pad, pad, pad, pad)
        }
        root.addView(TextView(this).apply {
            setText(R.string.songs_note)
            textSize = 14f
        })

        val spinner = Spinner(this)
        spinner.adapter = ArrayAdapter(
            this, android.R.layout.simple_spinner_dropdown_item, TamilTime.dayNames
        )
        spinner.setSelection(day)
        spinner.onItemSelectedListener = object : AdapterView.OnItemSelectedListener {
            override fun onItemSelected(p: AdapterView<*>?, v: View?, pos: Int, id: Long) {
                day = pos
                refresh()
            }

            override fun onNothingSelected(p: AdapterView<*>?) {}
        }
        root.addView(spinner)

        root.addView(Button(this).apply {
            setText(R.string.pick_many)
            setOnClickListener { openPicker(REQ_MULTI, true) }
        })
        root.addView(Button(this).apply {
            setText(R.string.copy_all)
            setOnClickListener {
                Songs.copyToAll(this@SongsActivity, day)
                Toast.makeText(this@SongsActivity, R.string.copied, Toast.LENGTH_SHORT).show()
            }
        })

        for (h in 0..23) {
            root.addView(TextView(this).apply {
                text = "%02d:00  (%s)".format(h, TamilTime.period(h))
                textSize = 18f
                setPadding(0, pad, 0, 0)
            })
            val row = LinearLayout(this).apply {
                orientation = LinearLayout.HORIZONTAL
                gravity = Gravity.CENTER_VERTICAL
            }
            val nameTv = TextView(this).apply { textSize = 14f }
            nameViews.add(nameTv)
            row.addView(
                nameTv,
                LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, 1f)
            )
            row.addView(Button(this).apply {
                setText(R.string.pick)
                setOnClickListener { openPicker(h, false) }
            })
            row.addView(Button(this).apply {
                setText(R.string.delete)
                setOnClickListener {
                    Songs.clear(this@SongsActivity, day, h)
                    refresh()
                }
            })
            root.addView(row)
        }

        setContentView(ScrollView(this).apply { addView(root) })
        refresh()
    }

    private fun refresh() {
        if (nameViews.size < 24) return
        val list = Songs.all(this, day)
        for (h in 0..23) {
            nameViews[h].text =
                if (list[h].uri.isBlank()) getString(R.string.no_song) else list[h].name
        }
    }

    private fun openPicker(requestCode: Int, multiple: Boolean) {
        val i = Intent(Intent.ACTION_OPEN_DOCUMENT).apply {
            addCategory(Intent.CATEGORY_OPENABLE)
            type = "audio/*"
            addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION or Intent.FLAG_GRANT_PERSISTABLE_URI_PERMISSION)
            if (multiple) putExtra(Intent.EXTRA_ALLOW_MULTIPLE, true)
        }
        startActivityForResult(i, requestCode)
    }

    @Deprecated("Deprecated in Java")
    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        super.onActivityResult(requestCode, resultCode, data)
        if (resultCode != RESULT_OK || data == null) return
        if (requestCode == REQ_MULTI) {
            val uris = ArrayList<Uri>()
            data.clipData?.let { cd ->
                for (i in 0 until cd.itemCount) uris.add(cd.getItemAt(i).uri)
            }
            if (uris.isEmpty()) data.data?.let { uris.add(it) }
            uris.sortedBy { Songs.displayName(this, it).lowercase() }
                .take(24)
                .forEachIndexed { hour, uri -> Songs.set(this, day, hour, uri) }
        } else if (requestCode in 0..23) {
            data.data?.let { Songs.set(this, day, requestCode, it) }
        }
        refresh()
    }
}
