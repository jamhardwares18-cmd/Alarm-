package com.example.tamilalarm

import android.Manifest
import android.app.Activity
import android.app.AlarmManager
import android.app.TimePickerDialog
import android.content.ComponentName
import android.content.Intent
import android.content.pm.PackageManager
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.os.PowerManager
import android.provider.Settings
import android.speech.tts.TextToSpeech
import android.widget.Button
import android.widget.LinearLayout
import android.widget.SeekBar
import android.widget.Switch
import android.widget.TextView
import android.widget.Toast
import java.util.Locale

class MainActivity : Activity() {

    private lateinit var statusText: TextView
    private lateinit var alarmList: LinearLayout
    private lateinit var quietStartBtn: Button
    private lateinit var quietEndBtn: Button

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        statusText = findViewById(R.id.statusText)
        alarmList = findViewById(R.id.alarmList)

        bindPercent(R.id.alarmVol, R.id.alarmVolLabel, Prefs.K_G_ALARM, R.string.alarm_volume)
        bindPercent(R.id.mediaVol, R.id.mediaVolLabel, Prefs.K_G_MEDIA, R.string.media_volume)

        val hourlySwitch = findViewById<Switch>(R.id.hourlySwitch)
        hourlySwitch.isChecked = Prefs.hourly(this)
        hourlySwitch.setOnCheckedChangeListener { _, on ->
            Prefs.setHourly(this, on)
            Scheduler.scheduleHourly(this)
        }
        bindFlag(R.id.hSongSwitch, Prefs.K_H_SONG)
        bindFlag(R.id.hTimeSwitch, Prefs.K_H_TIME)
        bindFlag(R.id.hVerseSwitch, Prefs.K_H_VERSE)

        val quietSwitch = findViewById<Switch>(R.id.quietSwitch)
        quietSwitch.isChecked = Prefs.quietOn(this)
        quietSwitch.setOnCheckedChangeListener { _, on ->
            Prefs.setQuietOn(this, on)
            Scheduler.scheduleHourly(this)
        }
        quietStartBtn = findViewById(R.id.quietStartBtn)
        quietEndBtn = findViewById(R.id.quietEndBtn)
        quietStartBtn.setOnClickListener { pickQuiet(true) }
        quietEndBtn.setOnClickListener { pickQuiet(false) }
        refreshQuietButtons()

        findViewById<Button>(R.id.testBtn).setOnClickListener {
            SpeakService.start(this, SpeakService.MODE_HOURLY)
        }
        findViewById<Button>(R.id.songsBtn).setOnClickListener {
            startActivity(Intent(this, SongsActivity::class.java))
        }
        findViewById<Button>(R.id.versesBtn).setOnClickListener {
            startActivity(Intent(this, VersesActivity::class.java))
        }
        findViewById<Button>(R.id.batteryBtn).setOnClickListener { allowBackground() }
        findViewById<Button>(R.id.addAlarmBtn).setOnClickListener {
            startActivity(Intent(this, AlarmEditActivity::class.java))
        }
        statusText.setOnClickListener { openTtsSettings() }

        if (Build.VERSION.SDK_INT >= 33 &&
            checkSelfPermission(Manifest.permission.POST_NOTIFICATIONS) != PackageManager.PERMISSION_GRANTED
        ) {
            requestPermissions(arrayOf(Manifest.permission.POST_NOTIFICATIONS), 1)
        }
        askExactAlarmIfNeeded()
        Scheduler.rescheduleAll(this)
    }

    override fun onResume() {
        super.onResume()
        checkTts()
        renderAlarms()
    }

    private fun bindFlag(viewId: Int, key: String) {
        val sw = findViewById<Switch>(viewId)
        sw.isChecked = Prefs.getFlag(this, key)
        sw.setOnCheckedChangeListener { _, on -> Prefs.setFlag(this, key, on) }
    }

    /** App-level volume 0..100 %. It only scales what this app plays; the phone's volume is untouched. */
    private fun bindPercent(barId: Int, labelId: Int, key: String, titleRes: Int) {
        val bar = findViewById<SeekBar>(barId)
        val label = findViewById<TextView>(labelId)
        fun show(p: Int) {
            label.text = "${getString(titleRes)}: $p%"
        }
        bar.progress = Prefs.getPct(this, key)
        show(bar.progress)
        bar.setOnSeekBarChangeListener(object : SeekBar.OnSeekBarChangeListener {
            override fun onProgressChanged(seekBar: SeekBar?, progress: Int, fromUser: Boolean) {
                show(progress)
                if (fromUser) Prefs.setPct(this@MainActivity, key, progress)
            }

            override fun onStartTrackingTouch(seekBar: SeekBar?) {}
            override fun onStopTrackingTouch(seekBar: SeekBar?) {}
        })
    }

    private fun fmtMin(m: Int): String {
        val h = m / 60
        val h12 = if (h % 12 == 0) 12 else h % 12
        return "$h12:${"%02d".format(m % 60)} ${if (h < 12) "AM" else "PM"}"
    }

    private fun refreshQuietButtons() {
        quietStartBtn.text = "தொடக்கம்: ${fmtMin(Prefs.quietStart(this))}"
        quietEndBtn.text = "முடிவு: ${fmtMin(Prefs.quietEnd(this))}"
    }

    private fun pickQuiet(start: Boolean) {
        val cur = if (start) Prefs.quietStart(this) else Prefs.quietEnd(this)
        TimePickerDialog(
            this,
            TimePickerDialog.OnTimeSetListener { _, h, m ->
                val v = h * 60 + m
                if (start) Prefs.setQuiet(this, v, Prefs.quietEnd(this))
                else Prefs.setQuiet(this, Prefs.quietStart(this), v)
                refreshQuietButtons()
                Scheduler.scheduleHourly(this)
            },
            cur / 60,
            cur % 60,
            false
        ).show()
    }

    /** 1st tap: battery-optimization exemption. Next taps: autostart / app settings. */
    private fun allowBackground() {
        val pm = getSystemService(POWER_SERVICE) as PowerManager
        if (!pm.isIgnoringBatteryOptimizations(packageName)) {
            try {
                startActivity(
                    Intent(
                        Settings.ACTION_REQUEST_IGNORE_BATTERY_OPTIMIZATIONS,
                        Uri.parse("package:$packageName")
                    )
                )
                return
            } catch (e: Exception) {
            }
        }
        Toast.makeText(
            this,
            "Autostart-ஐ ON செய்து, Battery: 'No restrictions' தேர்ந்தெடுக்கவும்",
            Toast.LENGTH_LONG
        ).show()
        val tries = listOf(
            Intent().setComponent(
                ComponentName(
                    "com.miui.securitycenter",
                    "com.miui.permcenter.autostart.AutoStartManagementActivity"
                )
            ),
            Intent(Settings.ACTION_APPLICATION_DETAILS_SETTINGS, Uri.parse("package:$packageName"))
        )
        for (i in tries) {
            try {
                startActivity(i)
                return
            } catch (e: Exception) {
            }
        }
    }

    private fun askExactAlarmIfNeeded() {
        if (Build.VERSION.SDK_INT in 31..32) {
            val am = getSystemService(AlarmManager::class.java)
            if (!am.canScheduleExactAlarms()) {
                try {
                    startActivity(
                        Intent(
                            Settings.ACTION_REQUEST_SCHEDULE_EXACT_ALARM,
                            Uri.parse("package:$packageName")
                        )
                    )
                } catch (e: Exception) {
                }
            }
        }
    }

    private fun checkTts() {
        var engine: TextToSpeech? = null
        engine = TextToSpeech(this) { status ->
            val msg = if (status == TextToSpeech.SUCCESS) {
                val r = engine?.isLanguageAvailable(Locale("ta", "IN")) ?: TextToSpeech.LANG_NOT_SUPPORTED
                if (r >= TextToSpeech.LANG_AVAILABLE) {
                    "தமிழ் குரல் தயார் ✓"
                } else {
                    "⚠ தமிழ் குரல் இல்லை. இங்கே தட்டி, Google Text-to-speech-ல் Tamil voice data install செய்யவும்."
                }
            } else {
                "⚠ Text-to-speech இயங்கவில்லை. இங்கே தட்டி settings பார்க்கவும்."
            }
            statusText.text = msg
            engine?.shutdown()
        }
    }

    private fun openTtsSettings() {
        try {
            startActivity(Intent("com.android.settings.TTS_SETTINGS"))
        } catch (e: Exception) {
            try {
                startActivity(Intent(Settings.ACTION_SETTINGS))
            } catch (e2: Exception) {
            }
        }
    }

    private fun label(a: AlarmItem): String {
        val h12 = if (a.hour % 12 == 0) 12 else a.hour % 12
        return "${TamilTime.period(a.hour)} $h12:${"%02d".format(a.minute)}"
    }

    private fun renderAlarms() {
        alarmList.removeAllViews()
        val list = Prefs.alarms(this).sortedWith(compareBy({ it.hour }, { it.minute }))
        if (list.isEmpty()) {
            alarmList.addView(TextView(this).apply { setText(R.string.no_alarms) })
            return
        }
        for (a in list) {
            val row = layoutInflater.inflate(R.layout.item_alarm, alarmList, false)
            row.findViewById<TextView>(R.id.timeText).text = label(a)
            row.findViewById<TextView>(R.id.daysText).text = TamilTime.daysSummary(a.days)
            row.findViewById<LinearLayout>(R.id.alarmInfo).setOnClickListener {
                startActivity(
                    Intent(this, AlarmEditActivity::class.java)
                        .putExtra(AlarmEditActivity.EXTRA_ID, a.id)
                )
            }
            val sw = row.findViewById<Switch>(R.id.alarmSwitch)
            sw.isChecked = a.enabled
            sw.setOnCheckedChangeListener { _, on ->
                val updated = a.copy(enabled = on)
                Prefs.updateAlarm(this, updated)
                Scheduler.scheduleAlarm(this, updated)
            }
            row.findViewById<Button>(R.id.testAlarmBtn).setOnClickListener {
                SpeakService.start(this, SpeakService.MODE_ALARM, a.id)
            }
            row.findViewById<Button>(R.id.deleteBtn).setOnClickListener {
                Scheduler.cancelAlarm(this, a.id)
                Prefs.removeAlarm(this, a.id)
                renderAlarms()
            }
            alarmList.addView(row)
        }
    }
}
